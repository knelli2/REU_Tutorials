# This sifts the gp files so that only times that are a multiple of the iteration scheme are in the horizon folder

from shutil import move, copy
from os.path import exists
from os import makedirs
from sys import argv

#################### THINGS TO CHANGE #################################
horizon_dir = argv[1]
iteration = int(argv[2])
#######################################################################

all_dir = horizon_dir + "all_horizon/"
filesTXT = all_dir + "files.txt"
f = open(filesTXT, 'r')

for line in f:
	time = line.strip()
	gp_file = "h.t" + time + ".ah1.gp"
	if int(time) % iteration == 0:
		copy(all_dir + gp_file, horizon_dir + gp_file) 


