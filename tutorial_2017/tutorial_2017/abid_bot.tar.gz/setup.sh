#Created by Abid Khan 07/14/16
#
#
#Given a system's h5data and/or horizon data, this script sets up everthing and makes a movie if desired. It requires 
#the parameters to be filled out below.
#
#This script works for all kinds of systems like NSNS, BHNS, BHBH, and SMS. There is no code in this script that needs to 
#be changed depending on the system, only the parameters. You may, however, need to update the following scripts:
#	
#	bw_many_folder_scripts/setmovie.py
#	bw_many_folder_scripts/run_many_movie_ranks.py
#	particle_code/particlePicker.py
#	grid_code/seedmaker.py
#
#In the root folder, you must have a folder called h5data/. In it should be 3d_data folders and a folder called horizon/
#In the horizon/ folder, there should be a folder called all_horizon/ and in that should be a a bunch of *.gp files. 
#also in the root folder, there must be a file called "bhns.xon". If your simulation requires field lines, then you must also 
#have the file "bhns-particles.mon" in your root directory as well. 
#
# @params
#
# it:				the iteration cycle in the h5 data
#
# dt:				how much time in code units pass between each frame
#
# firstTime:			this is a string that is 017.11f number (5 digits left of the decimal, and 11 digits right 
#           			right of it, both zero padded). The value is the time in code units of the very first frame. 
#				You can find this by looking at the first iteration number in the first 3d_data* folder, and 
#				convert that into code units of time. Then look at at "bhns.xon" and look for that time. Copy
#				that time exactly into "firstTime" but not using scientific notation. 
#
# M: 				the ADM mass
#
# offset: 			take the value of "firstTime" and divide it by "dt" the result should be an integer, and 
#         			that is the offset. Alternatively, you can look at the very first iteration number of the 
#         			h5 data, and divide it by the iteration step, "it". 
#
# arg1, arg2, arg3, arg4: 	these are arguments that you'll be passing into particlePicker.py. This 
#			  	will be different objects depending on what the system is. For example, 
#			  	for NSNS, the 4 arguments will be the xy coordinates of their center of masses.
#			  	These arguments are there for your leisure. You may not need them at all.
#			  	make sure you modify particlePicker.py before running this script
#
# numStars:			The number of stellar objects in our initial system. This is needed to determine where to center
#				the camera when filming.
#
# maxdensity:			The maximum density value in the initial time. This is found in the "bhns.mon" file 9th column.
#				Make sure it the time row corresponds to "firstTime". This variable is used in "run_many_movie_rankes.py"
#				when defining the logrho variable: 
#					DefineScalarExpression("logrha","log10(<MHD_EVOLVE--rho_b>/" + max_density + ")")	
#
# time_offset:			This parameter is rarely nonzero. time_offset is described by the following relation
#					t/M = ( (iteration number)*(dt)/(it) + (time_offset) )/M
#				time_offset may be nonzero if there is regridding involved.
#
# fields:			This is set to "true" if we want to show magnetic field lines. Otherwise, set it to "false"
#
# extend:			Sometimes, the particles only surround one stellar object. For example our NSNS cases only have 
#				particles surrounding one NS. Set this variable to "true" to reflect those particles to the other stellar object.
#				Note this must be set to "false" if we're dealing with only one stellar object like a SMS
#
# vol1XML: 			The full path to the volume attributes xml file. This is file is usually placed in "bw_many_folder_scripts/atts/"
#
# vol2XML:			If you need another volume xml file for your movie (say for later times), then use this variable. Both these variables are 
#				used in "setmovie.py"
#
# viewXML:			The full path to the view attribute xml file. this is usually place in "bw_many_folder_scripts/atts/".
#
#
# ONE FINAL NOTE: 	this code is pretty general for all cases, but it may not be general enough. If you find a case that is not covered in this code, 
#			then I would encourage you to generalize the code to include that case. This is mainly done through "if" statements and such.
#			For example, if you're dealing with a BHBH case, I haven't included code that deals with two black holes. This is something you 
#			would need to add. 


##################################### THINGS TO CHANGE ##############################################
it="512"
dt="35.9298245614"
firstTime="00970.10526316000"
M="4.9457"
offset=27
arg1="-18.187452396"
arg2="-1.1559932738"
arg3="17.015136177"
arg4="0.71542300828"
numStars=2
maxdensity="0.00072371856539"
time_offset="0"
fields=true
extend=true
vol1XML="/u/sciteam/skhan/NSNS/Prompt_collapse_016v018/int/bw_many_folder_scripts/atts/nsns_bright.xml"
vol2XML="/u/sciteam/skhan/NSNS/Prompt_collapse_016v018/int/bw_many_folder_scripts/atts/nsns_dim.xml"
viewXML="/u/sciteam/skhan/NSNS/Prompt_collapse_016v018/int/bw_many_folder_scripts/atts/c0.xml"
#####################################################################################################

root=$PWD

echo "creating folders"
rm -rf $root"/xml/"
mkdir $root"/xml/"
cd $root"/h5data/"
for i in $(ls -d 3d_data*)
do
	if [ $(ls $i | wc -l) -eq 0 ]
	then
		rm -rf $i
	else
		rm -rf $root"/xml/"$i
		mkdir $root"/xml/"$i
	fi
done

[ -d $root"/h5data/horizon/" ] && bhForms=true || bhForms=false 

if $bhForms
then
	echo "setting up black hole stuff..."

	cp $root"/gpto3d.cpp" $root"/h5data/horizon/"
	cp $root"/sift_gp.py" $root"/center_lister.py" $root"/h5data/horizon/all_horizon/"
	rm -rf $root"/bhdata/"
	mkdir $root"/bhdata/"

	echo "		sifting *.gp files and creating 'bhcen.txt'"
	cd $root"/h5data/horizon/all_horizon/"
	ls h.t*.gp | sed 's/h.t//' | sed 's/.ah1.gp//' | sort -n > files.txt

	python sift_gp.py $root"/h5data/horizon/" $it
	python center_lister.py $root"/" $it $dt

	echo "		creating bhdata"
	cd $root"/h5data/horizon/"
	g++ gpto3d.cpp -o gpto3d
	./gpto3d $root"/bhdata/" h.t*
	echo "done"
fi

if $fields
then

	echo "setting up particles"
	rm -rf $root"/seeds/"
	mkdir $root"/seeds/"
	cp $root"/bhns-particles.mon" $root"/bhns.xon" $root"/particle_code/misc/"

	cd $root"/particle_code/misc/"
	./makeparts.awk $root"/particle_code/misc/"

	mkdir $root"/particle_code/misc/dat_shortened/"
	python dat_cut.py $root"/" $firstTime $dt
	rm -rf $root"/particle_code/misc/dat/"
	mv $root"/particle_code/misc/dat_shortened/" $root"/particle_code/misc/dat/"
	cd $root"/particle_code/misc/dat/"
	ls > $root"/particle_code/misc/files.txt"
	cd $root"/particle_code/misc/"

	if $extend
	then
		echo "	reflecting seed points"
		python extend.py $root"/particle_code/misc/"
		mv $root"/particle_code/misc/extended/" $root"/particle_code/dat/"
		rm -rf $root"/particle_code/misc/dat/"
	else
		mv $root"/particle_code/misc/dat/" $root"/particle_code/dat/"
	fi

	echo "	making particle seeds"
	cd $root"/particle_code/"
	python particlePicker.py $dt $firstTime $root"/particle_code/" $arg1 $arg2 $arg3 $arg4
	cp seeds/* ../seeds/

	if $bhForms
	then
		echo "	making grid seeds"
		cd $root"/grid_code/"
		python seedmaker.py $root"/" $dt
		cp bhseeds/* ../seeds/
	fi
	echo "done"

fi

echo "making cm.txt"
cd $root"/particle_code/misc/"
python cmmake.py $numStars $root"/"

if $bhForms
then
	cd $root"/grid_code/"
	python cm_append.py $root"/"
	cd $root
else
	cp $root"/particle_code/misc/cm.txt" $root"/cm.txt"
fi


echo "running cray"
cd $root"/bw_many_folder_scripts/"
./cray.sh $it $root"/h5data"
python rmdupes.py
./SetMovie.sh $root"/" $it $dt $M $offset $fields $time_offset $vol1XML $vol2XML $viewXML
./runMovie.sh $root $maxdensity
echo "setup complete!"
