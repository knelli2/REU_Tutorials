from math import pi, cos, sin
from os.path import isfile, basename
from os import makedirs
from shutil import rmtree
from bisect import bisect_left
import numpy as np
from sys import argv

root_dir = argv[1]
time_it = float(argv[2])

grid_code_dir = root_dir + "grid_code/"
bhseed_dir = grid_code_dir + "bhseeds/" 
filesOrigin = root_dir + "particle_code/filesOrigin.txt"

def make_seed_file(myTime, timeArray, cmList):
	pos = (np.abs(timeArray - myTime)).argmin()

	xc = cmList[pos][0]
	yc = cmList[pos][1]
	zc = cmList[pos][2]

	fName = "%010.3f" % myTime
	outfile = open(bhseed_dir + fName + ".txt", 'w')
############################################THING TO CHANGE###################################################
# Here you have the ability to modify where the ring of points are going to be above and below the black hole. 
# This section is the only place you should change anything. 


	r = 3.0
	m_steps = 20
	for m in range(m_steps):
		theta = 2*pi*m/m_steps
		x = xc + r*cos(theta)
		y = yc + r*sin(theta)
		z = zc + 6.0
		outfile.write(str(x) + "\t" + str(y) + "\t" + str(z) + "\n")
		outfile.write(str(x) + "\t" + str(y) + "\t" + str(-z) + "\n")
	outfile.close()
	return pos
############################################################################################################
print "removing old seeds..."
rmtree(bhseed_dir)
makedirs(bhseed_dir)

# set up the timeList and cmList arrays from bhcen.txt
print "creating new seeds..."
f = open(grid_code_dir + "bhcen.txt", 'r')
timeList = []
cmList = []
for line in f:
	data = line.split()
	t = float(data[0])
	x = float(data[1])
	y = float(data[2])
	z = float(data[3])

	timeList.append(t)
	cmList.append( [x, y, z] )
f.close()

timeArray = np.asarray(timeList)
	
# write seed files that replace the seed files from particles
datList = open(filesOrigin, 'r')
for line in datList:
	fileName = basename(line[:-1])
	myTime = float(fileName[:-4])
	if myTime >= timeList[0]:
		make_seed_file(myTime, timeArray, cmList)
datList.close()


# write seed files for times where particle data is wanting
myTime = myTime + time_it
while myTime < timeList[-1] + time_it:
	pos = make_seed_file(myTime, timeArray, cmList)
	myTime = timeList[pos] + time_it
print myTime
