#This file appends "bhcen.txt" to "cm.txt".  

from sys import argv

rootdir = argv[1]

cmFile = open(rootdir + "particle_code/misc/cm.txt", 'r')
bhFile = open(rootdir + "grid_code/bhcen.txt", 'r')
outFile = open(rootdir + "cm.txt", 'w')

bh_line = bhFile.readline()
bh_data = bh_line.split()
bh_time = float(bh_data[0])

for line in cmFile:
	cm_data = line.split()
	cm_time = float(cm_data[0])
	if cm_time >= bh_time:
		outFile.write(bh_line)
		break
	outFile.write(line)
cmFile.close()

for line in bhFile:
	outFile.write(line)
bhFile.close()
outFile.close()
