#This script undoes everything that setup.sh has done. It's a nice restart tool

root=$PWD

echo "cleaning root"
rm -rf $root"/xml/"
rm -rf $root"/bhdata/"
rm -rf $root"/seeds/"
rm -rf $root"/cm.txt"

echo "cleaning h5data/horizon/"
cd $root"/h5data/horizon/"
rm -rf gpto3d.cpp
cd $root"/h5data/horizon/all_horizon/"
rm -rf center_lister.py sift_gp.py files.txt 

echo "cleang grid_code/"
cd $root"/grid_code/"
rm -rf bhcen.txt bhseeds/*

echo "cleaning particle_code/"
cd $root"/particle_code/"
rm -rf dat/ filesOrigin.txt seeds/*
cd $root"/particle_code/misc/"
rm -rf bhns-particles.mon bhns.xon cm.txt extended/ files.txt part.txt reduced_bhns-particles.mon

echo "cleaning bw_many_folder_scripts/"
cd $root"/bw_many_folder_scripts/"
rm -rf *.txt
rm -rf movies/*
rm -rf visitlog.py
rm -rf logs/*

echo "cleaning done!"
cd $root
