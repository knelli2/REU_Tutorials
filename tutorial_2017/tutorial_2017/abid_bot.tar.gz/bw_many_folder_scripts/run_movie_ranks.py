#Created by Brian Taylor

#This script runs the movie once you have created all the necessary xml files
#It's still being writen, obviously.

#Source("/home/projects/bhbh_mag_inspiral_extras/many_folders_code/run_movie.py")

#Run with something like visit -cli -nowin -s run_movie.py "h5dir" "extrasDir" "bhdir" "savefolder"

import random
import csv
import sys
import time

from os import listdir
from os.path import isfile, join
from fnmatch import fnmatch

###############################################################################
#search for all the necessary data (preprocessing)
###############################################################################

print sys.argv

h5dir = sys.argv[6]
extrasDir = sys.argv[7] 
saveFolder = sys.argv[8]
rank = int(sys.argv[9])
total_ranks = int(sys.argv[10])
streamXML = sys.argv[11]
max_density = sys.argv[12]

time.strftime("%Y-%m-%d %H:%M:%S")

#append a '/' if necessary
if(h5dir[-1] != '/'):
    h5dir = h5dir + '/'
if(extrasDir[-1] != '/'):
    extrasDir = extrasDir + '/'

#The first line picks out the files that contain "volume_" in the directory, extrasDir
#The sorting should sort in numerical order

volumeXML = [ f for f in listdir(extrasDir) if isfile(join(extrasDir,f)) and f.find("volume_")  != -1 ]
volumeXML.sort()
print "volumeXML",volumeXML

particlesTXT = [ f for f in listdir(extrasDir) if isfile(join(extrasDir,f)) and f.find("particles_") != -1 ]
particlesTXT.sort()

viewXML = [ f for f in listdir(extrasDir) if isfile(join(extrasDir,f)) and f.find("view_") != -1 ]
viewXML.sort()

timeTXT = [ f for f in listdir(extrasDir) if isfile(join(extrasDir,f)) and f.find("time_") != -1 ]
timeTXT.sort()

bh3D = [ f for f in listdir(extrasDir) if isfile(join(extrasDir,f)) and f.find("bh1_") != -1 ]
bh3D.sort()

#make a copy of particlesXML and turn it into numbers by removing "particles_" and ".xml"
stateList = viewXML[:]
for i in range(len(stateList)):
    stateList[i] = int(stateList[i][-8:-4])

stateList.sort()
print "statList ",stateList

def bh_formed():
	return len(bh3D) > 0 

#This adjusts the bh_*.3d files so that the black hole doesn't show up earlier than it's supposed to
if bh_formed():
	for i in stateList:
		bhFile = extrasDir + 'bh1_' + str(i).zfill(6) + '.3d'
		if not isfile(bhFile):
			f = open(bhFile, 'w')
			f.write("x\ty\tz\tbh1p\n")
			f.write("0\t0\t0\t0")
			f.close()
	
			

def fields():
	return len(particlesTXT) > 0

print "bh_formed: ", bh_formed()
print "fields: ", fields()

###############################################################################
#load the databases
###############################################################################

Bxdir = h5dir + "Bx.file_* database"
Bydir = h5dir + "By.file_* database"
Bzdir = h5dir + "Bz.file_* database"
rho_bdir = h5dir + "rho_b.file_* database"
bh1dir = extrasDir + "bh1_*.3d database"

print "Loading rho..."
OpenDatabase(rho_bdir,0,"CarpetHDF5_2.1")
print "\tDone"
DefineScalarExpression("rho_b","conn_cmfe(<" + rho_bdir + "[0]id:MHD_EVOLVE--rho_b>, <Carpet AMR-grid>)")
DefineScalarExpression("logrha","log10(<MHD_EVOLVE--rho_b>/" + max_density + ")")

if fields():
	print "Loading Bx..."
	OpenDatabase(Bxdir,0,"CarpetHDF5_2.1")
	print "\tDone"

	print "Loading By..."
	OpenDatabase(Bydir,0,"CarpetHDF5_2.1")
	print "\tDone"

	print "Loading Bz..."
	OpenDatabase(Bzdir,0,"CarpetHDF5_2.1")
	print "\tDone"

	DefineScalarExpression("Bx","conn_cmfe(<" + Bxdir + "[0]id:MHD_EVOLVE--Bx>, <Carpet AMR-grid>)")
	DefineScalarExpression("By","conn_cmfe(<" + Bydir + "[0]id:MHD_EVOLVE--By>, <Carpet AMR-grid>)")
	DefineScalarExpression("Bz","conn_cmfe(<" + Bzdir + "[0]id:MHD_EVOLVE--Bz>, <Carpet AMR-grid>)")
	DefineVectorExpression("BVec","{Bx,By,Bz}")

if bh_formed():
	print "Loading bh's..."
	OpenDatabase(bh1dir)
	print "\tDone"

if bh_formed():
	dbs = (Bxdir, Bydir, Bzdir, rho_bdir, bh1dir) if fields() else (rho_bdir, bh1dir)
else:
	dbs = (Bxdir, Bydir, Bzdir, rho_bdir) if fields() else (rho_bdir)

CreateDatabaseCorrelation("Everything", dbs, 0)

time.strftime("%Y-%m-%d %H:%M:%S")
###############################################################################
#load the plots
###############################################################################

bh_idx = 2 if fields() else 1

DeleteAllPlots()

ref = ReflectAttributes()
ref.reflections = (1,0,0,0,1,0,0,0)

#add Density Volume Plot (0)################
ActivateDatabase(rho_bdir)
AddPlot("Volume","logrha")     #plot 0

vol = VolumeAttributes()
SetActivePlots(0)

AddOperator("Reflect")
SetOperatorOptions(ref)

#add Streamline Plot (1)####################
if fields():
	ActivateDatabase(Bxdir)
	AddPlot("Streamline","BVec")	#plot 1

	SetActivePlots(1)

	AddOperator("Reflect")
	SetOperatorOptions(ref)

	stream_particles = StreamlineAttributes()

#add bhplots (bh_idx) ########################
if bh_formed():
	ActivateDatabase(bh1dir)
	AddPlot("Pseudocolor","bh1p")

	Pseudo = PseudocolorAttributes()
	SetActivePlots(bh_idx)
	AddOperator("Delaunay")
	AddOperator("Reflect")
	SetOperatorOptions(ref)

	Pseudo.colorTableName = "gray"
	Pseudo.legendFlag = 0
	Pseudo.lightingFlag = 0

	SetPlotOptions(Pseudo)

myView = GetView3D()
DrawPlots()
###############################################################################
#set up the annotations
###############################################################################

#Annotations and View ########################

Ann = AnnotationAttributes()
Ann.backgroundMode = Ann.Solid
Ann.backgroundColor = (55,118,255,255) #stu blue
#Ann.backgroundColor = (0,0,0,255) #black
#Ann.legendFlag = 0
Ann.databaseInfoFlag = 0
Ann.userInfoFlag = 0
Ann.axes3D.visible = 0
Ann.axes3D.triadFlag = 0
Ann.axes3D.bboxFlag = 0
SetAnnotationAttributes(Ann)

# Clock
txt = CreateAnnotationObject("Text2D")
txt.position = (0.75, 0.95) # (x,y), where x and y range from 0 to 1
txt.useForegroundForTextColor = 0
txt.textColor = (255, 255, 255, 255)
txt.fontBold = 1
txt.fontFamily = txt.Times # Because I think Times looks cooler

print "Annotations set up"

###############################################################################
#save window settings
###############################################################################

s = SaveWindowAttributes()
s.format = s.PNG
s.fileName = saveFolder
s.width = 1920 
s.height = 1080
s.screenCapture = 0
s.stereo = 0 #Setting for 3D movie
s.resConstraint = s.NoConstraint
SetSaveWindowAttributes(s)

###############################################################################
#start the movie
###############################################################################

print "starting filming"
time.strftime("%Y-%m-%d %H:%M:%S")

print stateList

tot_frames = len(stateList)

frame_start = int(round((float(rank)/total_ranks)*tot_frames))
frame_end = int(round(((rank+1.0)/total_ranks)*tot_frames))

#for state in stateList:
for i in range(frame_start,frame_end):

	state = stateList[i]
	print "loading state ", state
	SetTimeSliderState(state)

	tcur = timeTXT[state][5:-4]
	print "t/M = %g" % int(tcur)
	txt.text = "t/M = %g" % int(tcur)

	print extrasDir + volumeXML[state]
	time.strftime("%Y-%m-%d %H:%M:%S")

	print "loading options"


	print LoadAttribute(extrasDir + volumeXML[state], vol) 
	print LoadAttribute(extrasDir + viewXML[state], myView)
	if fields():
		print LoadAttribute(streamXML, stream_particles)
		### change point particles ###
		file1 = open(extrasDir + particlesTXT[state],'r')
		data1 = csv.reader(file1,delimiter='\t')
		table1 = [row for row in data1]
		d1 = []
		for i in range(len(table1)):
			for j in range(len(table1[i])):
				d1.append(table1[i][j])
		d1 = map(float,d1)
		mytuple1 = tuple(d1)
		stream_particles.pointList = mytuple1
		############################

	### adjust the cm focus ###
	cmfile = open(extrasDir + timeTXT[state], 'r')
	cmarray = cmfile.readline().split()
	x = float(cmarray[0])
	y = float(cmarray[1])
	z = float(cmarray[2])
	myView.focus = (x,y,z)
	###########################

	######implement loaded plot settings
	print "setting settings"
	print SetActivePlots(0), SetPlotOptions(vol)
	if fields():
		print SetActivePlots(1), SetPlotOptions(stream_particles)
	print SetView3D(myView)
	print "\nprinting myview"
	print myView	
	print RedrawWindow()
	SaveWindow()

	print "saved window"
	time.strftime("%Y-%m-%d %H:%M:%S")

sys.exit()
