from shutil import rmtree

f = open("duplicate.txt", 'r')
f.readline()
f.readline()
for line in f:
	rmtree(line[:-1])	
	rmtree(line[:-29]  + "xml/" + line[-22:-1])
