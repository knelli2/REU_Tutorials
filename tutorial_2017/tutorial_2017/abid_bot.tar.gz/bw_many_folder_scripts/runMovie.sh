#####begin things you have to change TODO

jobName=nsns_fields
root=$1
h5dir=$root/h5data
extrasDir=$root/xml
h5prefix=3d_data_

########run movies variables

manypbsfile=$root/bw_many_folder_scripts/manyFoldersSubwranks.pbs
picsavedir=$root/bw_many_folder_scripts/movies
visitScript=$root/bw_many_folder_scripts/run_movie_ranks.py
streamXML=$root/bw_many_folder_scripts/atts/nsns_stream_0.xml
totranks=5
#####end things you have to change

#remove trailing '/'
extrasDir=$( echo $extrasDir | sed "s,/$,,")
h5dir=$( echo $h5dir | sed "s,/$,,")
savefolder=$( echo $savefolder | sed "s,/$,,")
picsavefolder=$( echo $picsavefolder | sed "s,/$,,")


##########This section submits the rest of the files.

count=1
picsavefolder=$picsavedir/$(date +%y%m%d_%H%M)
mkdir -p $picsavefolder

for dir in $(ls -d ${h5dir}"/"$h5prefix* )
do
    blah=$(ls -d -1 $extrasDir/** | sed -n ${count}p) 
    tosave="$picsavefolder"/movie_$(printf "%03d" $count)_

#if [ $count -lt 2 ]
#then
    for rank in `seq 0 $(( $totranks - 1 ))`;
    do
            echo submitting job $count with rank = $rank
            qsub -N $jobName"_"$count"_"$rank -v VISITSCRIPT=$visitScript,H5=$dir,EXTRAS=$blah,SAVEFOLDER=$tosave$(printf "%03d" $rank)"_",RANK=$rank,TOTRANKS=$totranks,STREAMXML=$streamXML,MAXDENS=$2 $manypbsfile
    done
#fi
    count=$((count+1))
done
