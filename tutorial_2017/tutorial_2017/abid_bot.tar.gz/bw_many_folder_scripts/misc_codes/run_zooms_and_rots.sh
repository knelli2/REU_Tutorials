zoom_in_flag=0
zoom_in_2_flag=0
zoom_out_flag=0

fly_over_flag=0
zoom_in_3_flag=0
fly_around_flag=1

rootdir=/u/sciteam/skhan/scratch/NSNS4/
savedir=${rootdir}nsns_extras/bw_many_folder_scripts/misc_codes/movies_zooms_rots/

# zoom_in
jobName=zoom_in
h5folder=3d_data_201512081346/
idx=4
savefolder=$savedir$jobName/
pyscript=zoom_in.py

if [ $zoom_in_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi

# zoom_in_2
h5folder=3d_data_201601120701/
idx=0

jobName=zoom_in_2
savefolder=$savedir$jobName/
pyscript=zoom_in_no_fields.py

if [ $zoom_in_2_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi

# zoom_out
jobName=zoom_out
savefolder=$savedir$jobName/
pyscript=zoom_out.py
if [ $zoom_out_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi

###################### TO CHANGE OVER TIME ###############################
h5folder=3d_data_201603292116/
idx=1
# fly_over
jobName=fly_over
savefolder=$savedir$jobName/
pyscript=fly_over.py
if [ $fly_over_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi

# zoom_in
jobName=zoom_in_3
savefolder=$savedir$jobName/
pyscript=zoom_in_3.py
if [ $zoom_in_3_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi

# fly_around
jobName=fly_around
savefolder=$savedir$jobName/
pyscript=fly_around.py
if [ $fly_around_flag -eq 1 ]
then
	./film.sh $rootdir $jobName $h5folder $idx $savefolder $pyscript
fi
