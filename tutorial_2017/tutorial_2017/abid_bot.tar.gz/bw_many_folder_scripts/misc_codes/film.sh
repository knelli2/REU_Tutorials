rootdir=$1
jobName=$2
h5folder=$3
idx=$4
savefolder=$5
pyscript=$6

manypbsfile=${rootdir}nsns_extras/bw_many_folder_scripts/misc_codes/film.pbs
visitScript=${rootdir}nsns_extras/bw_many_folder_scripts/misc_codes/${pyscript}


totranks=100

rm -rf $savefolder
mkdir $savefolder

for rank in `seq 0 $(( $totranks - 1 ))`
do
	echo submitting job with rank = $rank
	echo qsub -N $jobName"_"$rank -v VISITSCRIPT=$visitScript,RANK=$rank,TOTRANKS=$totranks $manypbsfile
	qsub -N $jobName"_"$rank -v VISITSCRIPT=$visitScript,RANK=$rank,TOTRANKS=$totranks,SAVEFOLDER=$savefolder,ROOTDIR=$rootdir,H5FOLDER=$h5folder,IDX=$idx $manypbsfile
done
