#####begin things you have to change TODO

jobName=nsns
rootdir=/u/sciteam/skhan/scratch/NSNS4/ #TODO make sure this is right
h5dir=${rootdir}nsns
extrasDir=${rootdir}nsns_extras/xml/ #TODO make this folder
h5prefix=3d_data_

########run movies variables

manypbsfile=${rootdir}nsns_extras/bw_many_folder_scripts/misc_codes/manyFoldersSubwranks.pbs
picsavedir=${rootdir}nsns_extras/bw_many_folder_scripts/movies
visitScript=${rootdir}nsns_extras/bw_many_folder_scripts/misc_codes/nofields_run_movie_ranks.py
totranks=5

#####end things you have to change

#remove trailing '/'
extrasDir=$( echo $extrasDir | sed "s,/$,,")
h5dir=$( echo $h5dir | sed "s,/$,,")
savefolder=$( echo $savefolder | sed "s,/$,,")
picsavefolder=$( echo $picsavefolder | sed "s,/$,,")

##########This section submits the rest of the files.

count=1
picsavefolder=$picsavedir/$(date +%y%m%d_%H%M)
mkdir -p $picsavefolder

for dir in $(ls -d ${h5dir}"/"$h5prefix* )
do
 if [ $count -gt 9 ] && [ $count -lt 56 ]
 then
    blah=$(ls -d -1 $extrasDir/** | sed -n ${count}p) 
    tosave="$picsavefolder"/movie_$(printf "%03d" $count)_

    for rank in `seq 0 $(( $totranks - 1 ))`;
    do
            echo submitting job $count with rank = $rank
	    echo qsub -N $jobName"_"$count"_"$rank -v VISITSCRIPT=$visitScript,H5=$dir,EXTRAS=$blah,SAVEFOLDER=$tosave$(printf "%03d" $rank)"_",BH=$blah,RANK=$rank,TOTRANKS=$totranks $manypbsfile
            qsub -N $jobName"_"$count"_"$rank -v VISITSCRIPT=$visitScript,H5=$dir,EXTRAS=$blah,SAVEFOLDER=$tosave$(printf "%03d" $rank)"_",BH=$blah,RANK=$rank,TOTRANKS=$totranks $manypbsfile
    done
 fi

    count=$((count+1))
done
