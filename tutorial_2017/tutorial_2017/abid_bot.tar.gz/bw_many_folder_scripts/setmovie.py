# This script sets up the xml files for each frame. This must be done before filming.

# Created by Abid Khan

import sys
from os import listdir
from os.path import isfile, join
import shutil
from distutils.util import strtobool

###############################################################################
#load in information about folders etc.
###############################################################################

print sys.argv

rootdir = sys.argv[1]
it = int(sys.argv[2])
dt = float(sys.argv[3])
M = float(sys.argv[4])
offset = int(sys.argv[5])
fields = strtobool(sys.argv[6])
time_offset = float(sys.argv[7])
vol_xml = sys.argv[8]
vol2_xml = sys.argv[9] # if you need another one
view_xml = sys.argv[10] # if you need to set a specific view_angle that's not given below

rootdir = rootdir if rootdir[-1] == '/' else rootdir + '/'

overlapFile = rootdir + "bw_many_folder_scripts/overlap.txt"
bhdir = rootdir + "bhdata/"
particleseedpath = rootdir + "seeds/"
xmldir = rootdir + "xml/"
cm_file = rootdir + "cm.txt"

attsdir = rootdir + "bw_many_folder_scripts/atts/"
c0 = attsdir + "c0.xml"
c1 = attsdir + "c1.xml"
c2 = attsdir + "c2.xml"
c3 = attsdir + "c3.xml"
c4 = attsdir + "c4.xml"


in_file = open(cm_file, 'r')
timeList = []
cmList = []
for line in in_file:
        data = line.split()
        t = float(data[0])
        x = float(data[1])
        y = float(data[2])
        z = float(data[3])
        timeList.append(t)
        cmList.append((x, y, z))

if fields:
	filelist_part = [ f for f in listdir(particleseedpath) if isfile(join(particleseedpath,f)) and f.find(".txt") > 0 ]
	filelist_part.sort()

###############################################################################
#movie functions
###############################################################################

def getFolder(state):
    frame_state=state+1                 # Plus 1 for frame_count
    overlap_txt=overlapFile           
    f_overlap=open(overlap_txt,'r')
    for n in range(5):                  # Skip the first 3 header lines
        f_overlap.readline()
    for line in f_overlap:
        line_str=line.split()
        frame_skip=int(line_str[0])
        if frame_skip < 0:              # Check gap flag
                print "Warning: gap's found in data"
                frame_skip = 0
        frame_total=int(line_str[1])
        folder_path=line_str[2]
        frame_count=frame_total - frame_skip
        if frame_state <= frame_count:
            return folder_path,frame_state - 1
        frame_state=frame_state - frame_count
    print "Error in arguments!"
    return "Error!",-1                  # Bad input argument
    f_overlap.close()

def run_mov_fixed_view(first_step,last_step,view,vol):

    for state in range(first_step,last_step,1):

        gotFolder,index = getFolder(state - first_step)
        print gotFolder,index
        saveFolder = xmldir + gotFolder[-21:]

        ####copy bhdata###
        src = bhdir + 'ht_' + str(it*state).zfill(7) + '.3d'
        dst = saveFolder + 'bh1_' + str(index).zfill(6) + '.3d'
        if isfile(src):
                print "ah found"
                shutil.copy2(src, dst)
        ##################

	###copy particle seed data###
	if fields:
		indexstep = state - first_step
		if(indexstep >= len(filelist_part)):
			indexstep = len(filelist_part) - 1

		src = particleseedpath + filelist_part[indexstep]
		dst = saveFolder + "particles_" + str(index).zfill(4) + ".txt"
		shutil.copy2(src,dst)
	#############################

	###copy volume data###
	src = vol
	dst = saveFolder + "volume_" + str(index).zfill(4) + ".xml"
	shutil.copy2(src,dst)
	######################


	###copy view data###
	src = view
        dst = saveFolder + "view_" + str(index).zfill(4) + ".xml"
	shutil.copy2(src,dst)
	####################


	###copy cm and time data###
        myTime = state*dt + time_offset
        tList = [ abs(x - myTime) for x in timeList ]
        pos = tList.index(min(tList))
        cm = cmList[pos]

        tidex = int(round(myTime/M))
        timeTXT = saveFolder + "time_" + str(tidex).zfill(4) + ".txt"
	f = open(timeTXT, 'w')
	f.write(str(cm[0]) + "\t" + str(cm[1]) + "\t" + str(cm[2]))
	f.close()
	###########################

def getTotalNumberOfFrames():
    f_overlap=open(overlapFile,'r')
    #skip the header
    for n in range(5):                  # Skip the first 3 header lines
        f_overlap.readline()

    #iterate through each line of the file. 
    #Subtract the first column from the second
    #to get the number of frames filmed in that 
    #folder. repeat and sum for all of the folders 
    tot_number_of_frames = 0

    for line in f_overlap:
        line_str=line.split()
        col1 = int(line_str[0])
        col2 = int(line_str[1])
        tot_number_of_frames += col2 - col1

    print "There are " , tot_number_of_frames, " frames!"
    return tot_number_of_frames


###############################################################################
#run movie functions
###############################################################################
# if you want you can do something like 
#
#run_mov_fixed_view(offset,115 + offset,c0,vol_xml)
#run_mov_fixed_view(115 + offset,370 + offset,vol_xml,c1)
#run_mov_fixed_view(370 + offset,getTotalNumberOfFrames() + offset,c2,vol_xml)
#

run_mov_fixed_view(offset,getTotalNumberOfFrames() + offset,view_xml,vol_xml)

