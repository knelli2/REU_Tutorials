################################# THINGS TO CHANGE #####################################
rootdir=$1
it=$2
dt=$3
M=$4
offset=$5
fields=$6
time_offset=$7
vol1XML=$8
vol2XML=$9
viewXML=${10}
########################################################################################



h5prefix=3d_data_
echo deleting xml files...
rm -rf ${xmldir}/$h5prefix*/*
echo creating xml files...
python setmovie.py $rootdir $it $dt $M $offset $fields $time_offset $vol1XML $vol2XML $viewXML > xml_log.txt


