#See THINGS TO CHANGE BELOW
#Modularized version of previous particle picker

#Adapted from Parts.cpp, particles.cpp etc.

#Author: Brian Taylor
#06/02/14

import particlePickerModule as pPM
from os.path import isfile
from sys import argv

def torus(xx,yy,zz):

	from math import sqrt
	xcen = -0.257056
	ycen = -4.858345
	zcen = 0

	x = xx - xcen
	y = yy - ycen
	z = zz - zcen

	R = 50. #major radius - http://en.wikipedia.org/wiki/Torus
	r = 45. #minor radius 

	Inside = (((R - sqrt(x**2 + y**2))**2 + z**2) < (r**2))
	return Inside

def two_sphere(x,y,z):
	import math

	#This is the radius of the sphere
	radius = 10.5

	#This is the position of the sphere
	x1_pos = 18.382397852 
	y1_pos = 1.2279383048 
	z1_pos = 0.

	x2_pos = -18.375826050 
	y2_pos = -1.2810730302  
	z2_pos = 0.

	#Measurement of the distance to the center of your defined sphere
	r1 = math.sqrt((x-x1_pos)**2 + (y-y1_pos)**2 + (z-z1_pos)**2)
	r2 = math.sqrt((x-x2_pos)**2 + (y-y2_pos)**2 + (z-z2_pos)**2)

	if(r1 < radius or r2 < radius):
		return 1
	else:
		return 0

def nearestNeighborLOP(ball, x1c, yc1, x2c, y2c):
	from math import sin, cos, pi

	z1c = 0.0
	z2c = 0.0

	listOfPoints = []

	if ball == 1:
		i_steps = 20
		j_steps = 40
		for r in [3, 6, 9]:
			for i in range(i_steps):
				theta = pi*i/i_steps
				for j in range(j_steps):
					phi = 2*pi*j/j_steps
					
					x1 = x1c + r*sin(theta)*cos(phi)
					y1 = y1c + r*sin(theta)*sin(phi)
					z1 = z1c + r*cos(theta)

					x2 = x2c + r*sin(theta)*cos(phi)
					y2 = y2c + r*sin(theta)*sin(phi)
					z2 = z2c + r*cos(theta)

					part1 = [x1, y1, z1]
					part2 = [x2, y2, z2]

					listOfPoints.append(part1)
					listOfPoints.append(part2)
	else:
		j_steps = 40
		for j in range(j_steps):
			phi = 2*pi*j/j_steps
			
			r = 9
			x1 = x1c + r*cos(phi)
			y1 = y1c + r*sin(phi)
			z1 = z1c + 0.1 

			x2 = x2c + r*cos(phi)
			y2 = y2c + r*sin(phi)
			z2 = z2c + 0.1 

			part1 = [x1, y1, z1]
			part2 = [x2, y2, z2]

			listOfPoints.append(part1)
			listOfPoints.append(part2)

			r = 3
			x1 = x1c + r*cos(phi)
			y1 = y1c + r*sin(phi)
			z1 = z1c + 8.0 

			x2 = x2c + r*cos(phi)
			y2 = y2c + r*sin(phi)
			z2 = z2c + 8.0 

			part1 = [x1, y1, z1]
			part2 = [x2, y2, z2]

			listOfPoints.append(part1)
			listOfPoints.append(part2)

	print "nearest neighbor should have " + str( len(listOfPoints) ) + " points"
	return listOfPoints
	

bigTimeStep = float(argv[1]) #512.0/14.25
first_time = argv[2] # '00970.10526316000'
root_dir =  argv[3] #'/u/sciteam/skhan/scratch/NSNS/Prompt_collapse_016vs018/ext_int/particle_code/'

############################################## THINGS TO CHANGE###############################################################
# This code calls on 4 additional arguments. They are passed from "setup.sh", and are for your leisure. If the system that 
# you're working on needs seed points that are a certain way, then you can modify the functions called and the parameters that 
# you want passed into this script. For example, in the NSNS system, we have the 4 parameters being the x-y coordinates of the 
# NS's centers so that we can track a ring of particles around them. You may want something different like a set of points that 
# are inside a torus of a specific inner and outer radius. 

x1c = float(argv[4]) #-18.186932987
y1c = float(argv[5]) #-1.1547453902

x2c = float(argv[6]) #17.014550369
y2c = float(argv[7]) #0.71418919815

folderDest = root_dir + 'seeds/'
datFolder = root_dir + 'dat/'
sourceFile = datFolder + first_time + '.dat'
filesOrigin = root_dir + 'filesOrigin.txt'
reflectZ = 1
maxNumberOfParticles = 100000
volumeFunction = two_sphere

if not isfile(filesOrigin):
	pPM.genFilesOriginNEW(bigTimeStep,datFolder, float(first_time), -1)

#pPM.genTxtFiles(pPM.findInVolume(sourceFile ,  maxNumberOfParticles, volumeFunction ), filesOrigin , folderDest,reflectZ)
pPM.genTxtFiles(pPM.nearestNeighbor(sourceFile, nearestNeighborLOP(0, x1c, y1c, x2c, y2c)), filesOrigin , folderDest,reflectZ)
##############################################################################################################################

