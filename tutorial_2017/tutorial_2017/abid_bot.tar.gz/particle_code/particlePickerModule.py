#Modularized version of previous particle picker codes

#Adapted from Parts.cpp, particles.cpp etc.

#Author: Brian Taylor
#06/02/14

#To generate particle files, you need to pick out two functions. 
#One function returns a list of line numbers. (e.g. findInVolume and nearestNeighbor)
#The other function takes a list of line numbers and generates .txt files (genTxtFiles)

#######
#NOTE - you shouldn't have to edit this code to get things working.
#Instead, use a seperate drive code to import this module and call the functions inside


print "PP Module Loaded"

def genTxtFiles(listOfLineNumbers, filesOrigin ,folderDest,reflectZ=1):
	print "Generating txt files.."
	from os.path import basename
#generates txt files for you given a listOfLineNumbers 
#which you can get from some other function


	#This is the easiest way 
	#to get rid of duplicates in listOfLineNumbers
	myset = set(listOfLineNumbers)
	listOfLineNumbers = list(myset)

	#sorts the list in accending order
	#so you only have to iterate through each data file once
	listOfLineNumbers.sort()
	print "we got " + str( len(listOfLineNumbers) ) + " particles"
	print "listOfLineNumbers\n",listOfLineNumbers

	#check if there is a / at the end. If not, add it
	if(folderDest[-1] != '/'):
		folderDest = folderDest + '/'

	#index = -1

	#iterate through each dat file
	fi = open(filesOrigin, 'r')
	for fOrigin in fi:

		fOrigin=fOrigin[:-1]
		fName=basename(fOrigin) # Extract the file name from path
		fName=fName[:-4]	# Rip off the ".dat" extension
		fName=float(fName) 	# Get rid of extra 0's
		fName="%010.3f"%fName   # Format the file name with 0 fill and padding

		#index += 1

		toRun = True

		#check if the option parameters have been specified.
		#don't write file if it is not in the range
#		if(startIdx != -1 and endIdx != -1):
#			if(not(startIdx <= index <= endIdx)):
#				toRun = False
#
#		print "toRun ",toRun, startIdx, index, endIdx
#
#		if toRun == False:
#			continue

		#saveFile is a text file which will contain the xyz coordinates
		#for our seeds
		mystring = folderDest + fName + '.txt'
		saveFile = open(mystring,'w')

		with open(fOrigin,'r') as datFile:
			particleCount = 0
			#iterate through the lines each datFile to save the particles
			for lineNumber,line in enumerate(datFile):

				#If all of the particles have been found, break for loop
				#In other words, if this chunk of code doesn't exist,
				#you get an out of index error for listOfLineNumbers
				if(particleCount >= len(listOfLineNumbers)):
					break

				#if a particle with the same line number 
				#has the line number we are looking at, save it to the text file
				if(listOfLineNumbers[particleCount] == lineNumber):
					particleCount+=1
					#save file
					data = line.split()

					#note - data[0] is t. data[1] is x etc.
					#save the xyz data points. 
					saveString = data[1] + '\t' + data[2] + '\t' + data[3]  + '\n'
					saveFile.write(saveString)

					if(reflectZ == 1):
						#reflect the z component and save
						saveString = data[1] + '\t' + data[2] + '\t' + '-' + data[3] + '\n'
						saveFile.write(saveString)

					

		saveFile.close()
	print "Done generating txt files!"

#similar to genFilesOrigin. This one doesn't require one to know the little time step.
#This function reads in the dat files at the proper time step. Usually we have too frequent dat files.
#This function parses the dat files by their name and gives you a list of strings which contain the absolute pathes
#for the dat files you'll want to use in picking seeds. 
#It also has more features. Yay. 

#bigTimeStep should be the timestep of your hdf5 files
#filesDir should be the director of your dat files.
#start and end time are the just that. Specify where your movie starts and ends 
#sig_fig is how many significant digits you want to compare your
#time (as determined by bigTimeStep * index) and folder time (as determined by 
#its name e.g. 1234.4.dat). You probably won't need to change this.

#safeImport set to true only loads in files that end in ".dat" and are files. 
#safeImport set to false loads in everything in your directory. Its much faster though. 
#Feel free to set to false if you are sure you only have dat files in filesDir
def genFilesOriginNEW(bigTimeStep,filesDir,startTime=0.,endTime=-1):
	import os
	import shutil
        from os.path import isfile, join
	from bisect import bisect_left

	print "Generating Files Origin..."

        if(filesDir[-1] != '/'):
                filesDir = filesDir + '/'

        #Gather the list of all the files
	myFiles = os.listdir(filesDir)

        #remove the last 4 characters corresponding to .dat and convert to float
	print "iterating through " + str(len(myFiles)) + " files"
	keyMap = {}
	myFloats = []
        for i in range(len(myFiles)):
		key = float(myFiles[i][:-4])
		map = myFiles[i]
                myFloats.append(key)
		keyMap[key] = map
	myFloats.sort()

        #get last number in 
        if endTime == -1:
                largestNumber = myFloats[-1]
        else:
                largestNumber = endTime

        shortList = []
	timeList = []
	cur = startTime
	while cur < largestNumber:
		timeList.append(cur)
		cur = cur + bigTimeStep

	for time in timeList: 
	
		pos = bisect_left(myFloats, time)
		if pos == 0:
			closest_time = myFloats[0]
		elif pos == len(myFloats):
			closest_time = myFloats[-1]
		else:
			before = myFloats[pos - 1]
			after = myFloats[pos]
			closest_time = before if ( abs(before - time) < abs(after - time) ) else after
		myFloats = myFloats[pos:]
		shortList.append(keyMap[closest_time])
		
	print len(shortList)," files found"

	filesOrigin = []
        filesOriginal = open(filesDir[:-4] + "filesOrigin.txt", 'w')
        for item in shortList:
                mystring = filesDir + item
                filesOriginal.write(mystring + "\n")
		filesOrigin.append(mystring)
	print "Done generating Files Origin!"
	filesOriginal.close()
        return filesOrigin


def genFilesOrigin(bigTimeStep,littleTimeStep,filesDir):
#this function generates a string list of files for you to use.

#Often these files will have a higher output then our hdf5 files
# you'll want the big time step to be the time step of your hdf5 files
#the little time step is the time step of your dat files.
# filesDir should be the directory of you dat files. There should be nothing except dat files in there

	#add a '/' if its not there
	if(filesDir[-1] != '/'):
		filesDir = filesDir + '/'

	#To hold a list of the files to be used to make particles
	filesOrigin = []

	#rounding insures that the number doesn't go down when division is exact
	#e.g. when you get a number that is about 49.999999999 - we want 50 not 49
	idxStep = int(round(bigTimeStep/float(littleTimeStep)))
	
	import os

	myFiles = os.listdir(filesDir)

	#remove last 4 characters i.e. '.dat'
	for i in range(len(myFiles)):
		myFiles[i] = myFiles[i][:-4]

	#sort the file list names. 
	#key=float makes it so they'll be sorted in numerical order
	myFiles.sort(key=float)

	#create new list which skips the big steps
	shortList = myFiles[::idxStep]

	#build up filesOrigin list
	# give it the full path file names of the dat files you'll want to use
	for item in shortList:
		mystring = filesDir + item + '.dat'
		filesOrigin.append(mystring)

	return filesOrigin

def findInVolume( sourceFile ,  maxNumberOfParticles, volumeFunction, Seed=-1 ):
# Finds line numbers based on particles in a volume. 
# This currently works for one source file only, but could be modified 

# sourceFile - This should be a string that contains the path to your source file for the given timestep you want to look at. These are typically .dat files. The first column should be time, the next three should be xyz coordinates
# maxNumberOfParticles - you want 50 particles? then put 50 here. You'll get the first 50 particles the code finds. If the code can't find 50 particles, then you get less.
# volumeFunction - this function defines your volume. It should have 3 inputs, xyz. If the input is in the volume, return 1. If it is outside the volume, return 0. There should be examples of a volume function below.


#Note - I've editted the code so that particles found isn't used
#There were basically two options when writing this this code. 
#The first was to just use the first maxNumberOfParticles found
#The second option was to find all of the particles in the volume
#and then output a random subset. 
#Currently the code implements the second option.
#If for whatever reason, the first option is necessary, you can
#use the commented out code as a start.

	print "Finding in volume..."
	import random

	listOfLineNumbers = []

	#particlesFound = 0

	with open(sourceFile,'r') as datFile:
		for lineNumber, line in enumerate(datFile):
			
			data = line.split()
			
			#data[0] is t. but it isn't necessary here.
			x = float(data[1])
			y = float(data[2])
			z = float(data[3])

			if(volumeFunction(x,y,z) == 1):
				listOfLineNumbers.append(lineNumber)
				#particlesFound += 1
				#if (particlesFound >= maxNumberOfParticles):
				#	return listOfLineNumbers

	#randomize list then use only max number of particles
	#This is so you can a random sample 
	#of the particles in the volume.
	#If you don't do this, the particles you get won't necessarily be random
	
	#The user has the option of specifing a seed so 
	#that the particles you get are the same everytime.

	if (Seed != -1):
		random.seed(Seed)
	else:
		random.seed()

	random.shuffle(listOfLineNumbers)
	shortList = listOfLineNumbers[:maxNumberOfParticles]

	print "We got " + str(len(shortList)) + " particles"
	print "Done finding in volume!"
	return shortList

def findInVolumeForAllTime( filesOrigin , maxNumberOfParticles, volumeFunction ,startIdx=-1,endIdx=-1 ):

	import random

	#Finds if particle enters volume at any time ever
	#TODO - test this function

	listOfLineNumbers = []

	#iterate through each dat file
	for fOrigin in filesOrigin:

		#check if the option parameters have been specified.
		#don't write file if it is not in the range
		if(startIdx != -1 and endIdx != -1):
			if(not(startIdx <= index <= endIdx)):
				break
		
		
		with open(fOrigin,'r') as datFile:
			for lineNumber, line in enumerate(datFile):
			
				data = line.split()
				
				#data[0] is t. but it isn't necessary here.
				x = float(data[1])
				y = float(data[2])
				z = float(data[3])

				if(volumeFunction(x,y,z) == 1):
					listOfLineNumbers.append(lineNumber)


	#randomize list then use only max number of particles
	random.shuffle(listOfLineNumbers)
	shortList = listOfLineNumbers[:maxNumberOfParticles]

	return shortList


	

def nearestNeighbor(sourceFile, listOfPoints): 
#Finds line numbers based on picking nearest neighbor to each point in a set of points. 
#By default, nearest neighbor is determined by finding the particle with the smallest euclidean distance

#listOfPoints - list of points. duh. listOfPoints[i][1] would be the y component of the ith particle.
#NOTE - you can load in a txt file with numpy.loadtxt() 
#sourceFile - This should be a string that contains the path to your source file for the given timestep you want to look at. These are typically .dat files. The first column should be time, the next three should be xyz coordinates

	print "Finding Nearest Neighbor..."
	listOfLineNumbers = []

	#go throught the list of given points for which we need to find the closest available particles to
	for i in range(len(listOfPoints)):
		x_seed = listOfPoints[i][0] 
		y_seed = listOfPoints[i][1]
		z_seed = listOfPoints[i][2]

		datFile = open(sourceFile,'r')

		#This is just set to a high number. 
		olddist = 1000000.

		#iterate through each particle in dataset to find nearest neighbor to given point
		for lineNumber, line in enumerate(datFile):

			data = line.split()
			
			t = float(data[0]) #this isn't necessary to have but, I put this line here in case there is confusion about why x comes from data[1] instead of data[0]
			x = float(data[1])
			y = float(data[2])
			z = float(data[3])

			#Euclidean Distance
			#You can change this to another function if you want. 
			#For example, you can add a bias by making the distance (x-x_seed)*(x-x_seed) + (y-y_seed)*(y-y_seed) + .4 * (z-z_seed)*(z-z_seed)
			#This changes the importance in the z distance when minimizing.
			newdist = (x-x_seed)*(x-x_seed) + (y-y_seed)*(y-y_seed) + (z-z_seed)*(z-z_seed)
			#if this new particle is closer, remember it
			if( newdist < olddist):
				nearest_x = x
				nearest_y = y
				nearest_z = z

				olddist = newdist

				saveline = lineNumber

			
		listOfLineNumbers.append(saveline) 

	 
	print "Nearest Neighbor finds " + str( len(listOfLineNumbers) ) + "points"
	print "Done finding Nearest Neighbor!"
	return listOfLineNumbers



########################################
#These are example functions to be used for defining a volume. 
#For good programming practices,
#don't edit these functions 
#instead, make new ones in your script that calls the module code

def cylinderVol(x,y,z):
	import math

	#This is the radius of the cylinder
	r_radius = 5.

	r = math.sqrt(x*x + y*y)

	if(r < r_radius):
		return 1
	else:
		return 0

def sphereVol(x,y,z):
	import math

	#This is the radius of the sphere
	r_radius = 10.

	#This is the position of the sphere
	x_pos = 18.324728837
	y_pos = 1.2159478556
	z_pos = 0.

	#Measurement of the distance to the center of your defined sphere
	r = math.sqrt((x-x_pos)*(x-x_pos) + (y-y_pos)*(y-y_pos) + (z-z_pos)*(z-z_pos))

	if(r < r_radius):
		return 1
	else:
		return 0

def torusVol(x,y,z):

	#TODO: STILL TESTING!

	import math

	R = 50. #major radius - http://en.wikipedia.org/wiki/Torus
	r = 30. #minor radius 

	Inside = (x*x+y*y+z*z-(r*r+R*R))**2 - 4*r*R*(r**2-z**2)

	if(Inside < 0):
		return 1
	else:
		return 0
