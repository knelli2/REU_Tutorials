# read in bh_specs.txt file
# go through each seed.txt file in seeds/ dir and match up time from bh_specs.txt file with seeds file
# go through each point in seed.txt and remove lines with points inside BH

def findNearestTimeidx(timeList, myTime):
	from bisect import bisect_left
	pos = bisect_left(timeList, myTime)
	if (pos != 0 and pos != len(timeList)):
		before = timeList[pos - 1]
		after = timeList[pos]
		return (pos - 1) if ( abs(before - myTime) < abs(after - myTime) ) else pos

from os.path import basename
from math import sqrt

bh_specs_file = '/u/sciteam/skhan/scratch/NSNS/nsns_extras/particle_code/misc/bh_specs.txt'
stxt = '/u/sciteam/skhan/scratch/NSNS/nsns_extras/particle_code/misc/bhseed_files_before_grid.txt'
srcDir = '/u/sciteam/skhan/scratch/NSNS/nsns_extras/particle_code/seeds/'
dstDir = '/u/sciteam/skhan/scratch/NSNS/nsns_extras/particle_code/misc/bhseeds_before_grid/'

bsf = open(bh_specs_file, 'r')
bsf.readline()

timeList = []
cenList = []
radList = []

for line in bsf:
	data = line.split()
	t = float(data[0])
	x = float(data[1])
	y = float(data[2])
	z = float(data[3])
	r = float(data[4])

	timeList.append(t)
	cenList.append( (x, y, z) )
	radList.append(r)
bsf.close()

st = open(stxt, 'r')
for line in st:
	line = line[:-1]
	fileName = basename(line)
	myTime = fileName[:-4]
	myTime = float(myTime)
	idx = findNearestTimeidx(timeList, myTime)

	bh_t = timeList[idx]
	bh_x = cenList[idx][0]
	bh_y = cenList[idx][1]
	bh_z = cenList[idx][2]
	bh_r = radList[idx]
	
	srcf = open(srcDir + fileName, 'r')
	dstf = open(dstDir + fileName, 'w')

	for s_line in srcf:
		data = s_line.split()
		x = float(data[0])
		y = float(data[1])
		z = float(data[2])
		
		r = sqrt( (x - bh_x)**2 + (y - bh_y)**2 + (z - bh_z)**2 )
		if r > bh_r:
			dstf.write(s_line)
	dstf.close()
	srcf.close()
st.close()
