# This script updates the data folders when new data arrives. Do this only if a black hole has formed. 
# Otherwise, just re-run "setup.sh".
# Run this code only after you run setup. Copy the parameters from "setup.sh" to here. 
##################################### THINGS TO CHANGE ##############################################
it="512"
dt="35.9298245614"
M="4.9457"
offset=27
maxdensity="0.00072371856539"
time_offset="0"
#####################################################################################################

root=$PWD
echo "creating folders"
rm -rf $root"/xml/"
mkdir $root"/xml/"
cd $root"/h5data/"
for i in $(ls -d 3d_data*)
do
        if [ $(ls $i | wc -l) -eq 0 ]
        then
                rm -rf $i
        else
                rm -rf $root"/xml/"$i
                mkdir $root"/xml/"$i
        fi
done


echo "setting up black hole stuff..."

cp $root"/gpto3d.cpp" $root"/h5data/horizon/"
cp $root"/sift_gp.py" $root"/center_lister.py" $root"/h5data/horizon/all_horizon/"
rm -rf $root"/bhdata/"
mkdir $root"/bhdata/"

echo "          sifting *.gp files and creating 'bhcen.txt'"
cd $root"/h5data/horizon/all_horizon/"
ls h.t*.gp | sed 's/h.t//' | sed 's/.ah1.gp//' | sort -n > files.txt

python sift_gp.py $root"/h5data/horizon/" $it
python center_lister.py $root"/" $it $dt

echo "          creating bhdata"
cd $root"/h5data/horizon/"
g++ gpto3d.cpp -o gpto3d
./gpto3d $root"/bhdata/" h.t*
echo "done"

[ -d $root"/seeds/" ] && fields=true || fields=false

if $fields
then

        echo "setting up particles"
     	echo "  making grid seeds"
	cd $root"/grid_code/"
	python seedmaker.py $root"/" $dt
	cp bhseeds/* ../seeds/
        echo "done"

fi

cd $root"/grid_code/"
python cm_append.py $root"/"

echo "running cray"
cd $root"/bw_many_folder_scripts/"
./cray.sh $it $root"/h5data"
python rmdupes.py
./SetMovie.sh $root"/" $it $dt $M $offset $fields $time_offset
./runMovie.sh $root $maxdensity
echo "setup complete!"

